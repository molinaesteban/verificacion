/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package auto;

import org.openqa.selenium.By;  
import org.openqa.selenium.JavascriptExecutor;  
import org.openqa.selenium.WebDriver;  
import org.openqa.selenium.chrome.ChromeDriver;  

public class Auto {
    
    public static void main(String[] args) {
       
        System.setProperty("webdriver.chrome.driver", "C:/Users/312C-08/Documents/chromedriver.exe");  
            
        WebDriver driver=new ChromeDriver();  
          
                 //Maximize the browser  
        //driver.manage().window().maximize();  
        
        
           //PUNTO 1
           /*
           driver.navigate().to("https://www.funlam.edu.co/");  
                    // Click on the Search button  
         
        driver.findElement(By.linkText("Bienestar")).click();  
        */
          
        
         
        
        //PUNTO 2
        
           
           /*
        driver.navigate().to("https://www.youtube.com/"); 
        driver.manage().window().maximize();  
        driver.findElement(By.id("search-input")).sendKeys("music");
        driver.findElement(By.id("search-icon-legacy")).click(); 
           */
           
           
                    //PUNTO 3
         /*
           driver.navigate().to("https://es-la.facebook.com/");  
         driver.manage().window().maximize();

            driver.close();
        */
         
        //PUNTO 4
        
        /*
        driver.navigate().to("https://academia.funlam.edu.co/uenlinea/index.jsf");
        
        driver.manage().window().maximize();  
        driver.findElement(By.id("form_login:j_idt43")).sendKeys("kleyver.callebe");
        driver.findElement(By.id("form_login:j_idt46")).click(); 
        //Luego la contraseña, ****/
        
        //punto 5     
        driver.navigate().to("https://www.gmail.com");
        driver.findElement(By.id("identifierId")).sendKeys("cristian.coloradoco@amigo.edu.co");
        driver.findElement(By.id("identifierNext")).click(); 
        driver.findElement(By.id("password")).sendKeys("");
        driver.findElement(By.id("passwordNext")).click();          
    }  
  
}

